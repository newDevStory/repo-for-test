import { axiosi } from "../../config/axios"
import axios from 'axios'

export const fetchAllCategories=async()=>{
    try {
        const res=await axios.get("http://localhost:3001//categories")
        return res.data
    } catch (error) {
        throw error.response.data
    }
}