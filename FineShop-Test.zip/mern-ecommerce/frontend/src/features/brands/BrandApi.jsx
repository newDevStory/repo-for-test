import { axiosi } from "../../config/axios";
import axios from 'axios'

export const fetchAllBrands=async()=>{
    try {
        const res=await axios.get("http://localhost:3001//brands")
        return res.data
    } catch (error) {
        throw error.response.data
    }
}