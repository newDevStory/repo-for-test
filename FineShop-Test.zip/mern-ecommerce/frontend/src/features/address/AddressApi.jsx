import { axiosi } from "../../config/axios";
import axios from 'axios';

export const addAddress=async(address)=>{
    try {
        const res=await axios.post("http://localhost:3001//address",address)
        return res.data
    } catch (error) {
        throw error.response.data
    }
}
export const fetchAddressByUserId=async(id)=>{
    try {
        const res=await axiosi.get(`/address/user/${id}`)
        return res.data
    } catch (error) {
        throw error.response.data
    }
}
export const updateAddressById=async(update)=>{
    try {
        const res=await axiosi.patch(`/address/${update._id}`,update)
        return res.data
    } catch (error) {
        throw error.response.data
    }
}
export const deleteAddressById=async(id)=>{
    try {
        const res=await axiosi.delete(`/address/${id}`)
        return res.data
    } catch (error) {
        throw error.response.data
    }
}